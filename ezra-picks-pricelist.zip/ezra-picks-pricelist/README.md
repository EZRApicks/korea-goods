# EZRA Picks 韓國品牌代購價目表

上傳到 GitHub 後，到 Settings → Pages，Source 選 `main` 分支、資料夾選 `/ (root)`，存檔後就會有公開網址。

- `index.html`：頁面內容與商品
- `css/style.css`：樣式
- `js/main.js`：品牌切換
- `images/`：logo 與商品照

品牌直連：在網址後加 `#verish`、`#ason`、`#matinkim`、`#standoil`、`#emis`、`#aeae`。
